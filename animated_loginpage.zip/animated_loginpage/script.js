function resetZIndex() {
    document.querySelector("#sign-in-panel").style.zIndex = 1;
    document.querySelector("#sign-up-panel").style.zIndex = 1;
    document.querySelector("#overlay-sign-in-panel").style.zIndex = 0;
    document.querySelector("#overlay-sign-up-panel").style.zIndex = 1;
}

document.querySelector("#switchToSignUp").addEventListener("click", () => {
    resetZIndex();
    document.querySelector("#sign-in-panel").style.opacity = 0;
    document.querySelector("#sign-in-panel").style.transform = "translateX(100%)";
    document.querySelector("#sign-in-panel").style.zIndex = 0;

    document.querySelector("#sign-up-panel").style.opacity = 1;
    document.querySelector("#sign-up-panel").style.transform = "translateX(0)";
    document.querySelector("#sign-up-panel").style.zIndex = 1;

    document.querySelector("#overlay-sign-in-panel").style.opacity = 1;
    document.querySelector("#overlay-sign-in-panel").style.transform = "translateX(0)";
    document.querySelector("#overlay-sign-in-panel").style.zIndex = 1;

    document.querySelector("#overlay-sign-up-panel").style.opacity = 0;
    document.querySelector("#overlay-sign-up-panel").style.transform = "translateX(-100%)";
    document.querySelector("#overlay-sign-up-panel").style.zIndex = 0;
});

document.querySelector("#switchToSignIn").addEventListener("click", () => {
    resetZIndex();
    document.querySelector("#sign-in-panel").style.opacity = 1;
    document.querySelector("#sign-in-panel").style.transform = "translateX(0)";
    document.querySelector("#sign-in-panel").style.zIndex = 1;

    document.querySelector("#sign-up-panel").style.opacity = 0;
    document.querySelector("#sign-up-panel").style.transform = "translateX(-100%)";
    document.querySelector("#sign-up-panel").style.zIndex = 0;

    document.querySelector("#overlay-sign-in-panel").style.opacity = 0;
    document.querySelector("#overlay-sign-in-panel").style.transform = "translateX(100%)";
    document.querySelector("#overlay-sign-in-panel").style.zIndex = 0;

    document.querySelector("#overlay-sign-up-panel").style.opacity = 1;
    document.querySelector("#overlay-sign-up-panel").style.transform = "translateX(0)";
    document.querySelector("#overlay-sign-up-panel").style.zIndex = 1;
});
